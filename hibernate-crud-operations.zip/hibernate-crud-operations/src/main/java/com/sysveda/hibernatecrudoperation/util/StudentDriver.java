package com.sysveda.hibernatecrudoperation.util;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.EntityTransaction;
import javax.persistence.Persistence;


import com.sysveda.hibernatecrudoperation.dto.Student;

public class StudentDriver {
	public static void main(String[] args) {
		 EntityManagerFactory factory = Persistence.createEntityManagerFactory("CustomerDB");
	        EntityManager entityManager = factory.createEntityManager();
	         EntityTransaction tra=entityManager.getTransaction();
	         tra.begin();
	         
//	        Student student = new Student();
//	       
//	        student.setStudentId(5);
//	        student.setName("gokul");
	        Student entity = entityManager.find(Student.class, 0);
//	        entityManager.remove(entity);
//            entity.setName("karthi bro");
////            entity.setStudentId(100);
//	         entityManager.merge(entity);
	        System.out.println(entity);
	        
	        tra.commit();
	         
	        entityManager.close();
	        factory.close();
	        
	}	            
}
